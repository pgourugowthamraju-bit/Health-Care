# MediCare Hospital — Modern Full-Stack Website

A responsive multi-page hospital management website built with HTML, CSS, JavaScript, Node.js and Express. It includes a patient portal and an administrator portal.

## Easiest way to start on Windows — no VS Code commands needed

1. Install **Node.js 18 or newer** from https://nodejs.org/ (one-time requirement).
2. Extract the complete ZIP file.
3. Open the extracted `MediCare_Hospital_Modern` folder.
4. Double-click **`START_MEDICARE.bat`**.
5. On first run, it automatically installs the project packages, creates the local `.env` file, starts the backend and opens your browser.
6. Keep the black terminal window open while using the website. Close it with `Ctrl+C` when finished.

The correct website address is **http://localhost:5000**.

**Do not open `index.html` directly and do not use VS Code Live Server for this full-stack project.** The website's login, appointment, patient dashboard and admin features require the Node.js backend.

If you prefer VS Code: open the `MediCare_Hospital_Project` folder and run `npm install` followed by `npm start` in the terminal.

## Demo administrator

- Email: `admin@medicare.test`
- Password: `Admin@123`

Change this demo password and remove demo credentials before any public deployment.

## Pages

- Home — modern landing page, quick actions, departments, doctor preview and founder feature.
- About — hospital story, values and founder photograph.
- Services — department and service information.
- Doctors — doctor directory and appointment links.
- Register / Login — patient account creation and sign-in.
- Patient Dashboard — appointment summary and status history.
- Appointment — appointment request form.
- Contact — enquiry form.
- Admin Dashboard — manage doctors, patient directory and appointment statuses.

## Working application features

- Express REST API
- Password hashing with bcrypt
- JWT-based login sessions
- Patient and administrator roles
- Appointment creation and patient appointment history
- Appointment status management (Pending, Approved, Completed, Cancelled)
- Doctor directory and admin add/remove controls
- Patient directory and dashboard counts
- Contact form
- JSON-file data persistence (no database server required)
- Responsive layout for desktop, tablet and mobile
- Founder image served from `frontend/assets/founder-photo.jpeg`

## Project structure

```text
MediCare_Hospital_Project/
├── backend/
│   ├── data/              # JSON data storage
│   ├── middleware/        # Authentication middleware
│   ├── routes/            # API route modules
│   ├── server.js
│   └── store.js
├── frontend/
│   ├── assets/            # Founder and profile images
│   ├── css/style.css
│   ├── js/app.js
│   ├── pages/              # Separate HTML pages
│   └── index.html
├── .env.example
├── package.json
├── README.md
└── start-windows.bat
```

## Important deployment and safety note

This is a functional educational/demo application, not a certified hospital information system. The seeded doctors, contact details and administrator are demonstration data. Do not collect real patient information or use this for clinical decisions. A real hospital launch requires a production database, HTTPS, secure session/cookie configuration, rate limiting, audit logs, backups, access-control review, privacy/legal compliance, real verified staff and services, and security testing. Replace the sample hospital contact details and confirm all operational claims before publishing.
