@echo off
setlocal
title Start MediCare Hospital
cd /d "%~dp0"

echo.
echo ==========================================
echo       MEDICARE HOSPITAL WEBSITE
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo Install Node.js 18 or newer from https://nodejs.org/
  echo Then double-click this file again.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js and try again.
  pause
  exit /b 1
)

if not exist package.json (
  echo ERROR: Please run this file from inside the MediCare_Hospital_Project folder.
  pause
  exit /b 1
)

if not exist node_modules (
  echo First-time setup: installing required packages. Please wait...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo Package installation failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)

if not exist .env (
  copy .env.example .env >nul
  echo Created local .env configuration.
)

echo.
echo Starting the hospital website...
echo Keep this black terminal window open while using the website.
echo Your browser will open at http://localhost:5000
echo To stop the website, press CTRL+C in this window.
echo.

start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 4; Start-Process 'http://localhost:5000'"
call npm start

echo.
echo The website server has stopped.
pause
