@echo off
setlocal
cd /d "%~dp0MediCare_Hospital_Project"
if not exist START_MEDICARE.bat (
  echo Could not find MediCare_Hospital_Project\START_MEDICARE.bat
  echo Extract the complete ZIP file before running this launcher.
  pause
  exit /b 1
)
call START_MEDICARE.bat
